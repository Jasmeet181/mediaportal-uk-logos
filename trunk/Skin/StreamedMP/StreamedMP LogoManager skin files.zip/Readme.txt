Readme for the StreamedMP LogoManager skin files
================================================

Extract and copy to:
C:\ProgramData\Team MediaPortal\MediaPortal\skin\StreamedMP

StreamedMP Issue 586, reported 10 July 2013:
https://code.google.com/p/streamedmp/issues/detail?id=586